# -*- coding: utf-8 -*-
"""
Created on Sat Oct  5 13:54:31 2019

@author: Oyelade
"""
from __future__ import division, print_function, absolute_import
import tensorflow as tf
#tf.enable_eager_execution()
import os
import numpy as np
#import imageio
from PIL import Image
from math import floor
import pathlib
import PIL 
import IPython.display as display
import shutil
#import tensorflow.contrib.eager as tfe
from tensorflow.keras.utils import to_categorical
import matplotlib.image as mpimg
import matplotlib.pyplot as plt 
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import csv
import cv2 as cv
import cv2
from numpy import where
from matplotlib import pyplot
from numpy import concatenate, savetxt, array    
from keras import backend as K


mdir='D:/TEHNAN/PhD/Gene Expression project/BRCA_Image-20220728T104807Z-001/After preprocessing'  #'/mdata/mias/train'
lung_cancer_train=mdir+''#'/mdata/mias/test'
lung_cancer_val=mdir+''#'/mdata/mias/val'




IMG_WIDTH=150 #299   1024 2560
IMG_HEIGHT=150 #299 1024  3328
NUM_CLASSES = 2
batch_size=16
buf_size=10000
AUTOTUNE=tf.data.experimental.AUTOTUNE
CLASS_NAMES=['Normal', 'Tumor'] #'CALC',

## Load the training data and return a list of the tfrecords file and the size of the dataset
## Multiple data sets have been created for this project, which one to be used can be set with the type argument
def getLabels():
    return CLASS_NAMES

def getDataSize(dType, dWhat):
    image_count=0
    val_count=0
    
    if dType ==1: #train data
        data=get_lung_cancer_image_training_data()[dWhat]
        val=get_lung_cancer_image_validation_data()[dWhat]
        if dWhat == 3: # for numpy files and not image files like .png 
           _images = np.load(val)
           val_count=_images.shape[0]
        else:
           val_dir = pathlib.Path(val)
           val_count = len(list(val_dir.glob('*')))
        
    if dType ==2: #validation data
         data=get_mias_image_validation_data()[dWhat]
         
    if dType ==3: #test data
         data=get_mias_image_test_data()[dWhat]
    
    if dWhat == 3: # for numpy files and not image files like .png 
        _images = np.load(data)
        image_count=_images.shape[0]
    else: 
        data_dir = pathlib.Path(data)
        image_count = len(list(data_dir.glob('*')))
        print(image_count)
        #print([item for item in data_dir.glob('*') if item.name != "LICENSE.txt"])
    
    return image_count, val_count

def prediction_filenames(dWhat):
    data=get_mias_image_test_data()[dWhat]
    data_dir = pathlib.Path(data)
    filenames=[item for item in data_dir.glob(data_dir.glob('*/*.jpg')) if item.name != "LICENSE.txt"]
    return filenames
    
def get_lung_cancer_image_training_data():
    train_files = [lung_cancer_train] #
    return train_files

def get_lung_cancer_image_validation_data():
    test_files = [lung_cancer_val] 
    return test_files


'getting images prepared as dataset format'
def get_label(file_path):
  parts = tf.strings.split(file_path, '/') # convert the path to a list of path components
  parts=tf.strings.split(parts[-1], '.')
  parts=tf.strings.split(parts[-2], '_')
  # The index last is the class-directory
  print(parts[-1])
  return parts[-1] == CLASS_NAMES

def decode_img(img):
  # convert the compressed string to a 3D uint8 tensor
  img = tf.image.decode_jpeg(img, channels=1)
  # Use `convert_image_dtype` to convert to floats in the [0,1] range.
  img = tf.image.convert_image_dtype(img, tf.float32)
  # resize the image to the desired size.
  return tf.image.resize(img, [IMG_WIDTH, IMG_HEIGHT])  #[1, IMG_WIDTH, IMG_HEIGHT]

def process_path(file_path):
  label = get_label(file_path)
  # load the raw data from the file as a string
  img = tf.io.read_file(file_path)
  img = decode_img(img)
  return img, label

def prepare_for_training(bs, ds, cache=False, shuffle_buffer_size=1000):
  # This is a small dataset, only load it once, and keep it in memory.
  # use `.cache(filename)` to cache preprocessing work for datasets that don't
  # fit in memory.  
  if cache:
    if isinstance(cache, str):
      ds = ds.cache(cache)
    else:
      ds = ds.cache()
  ds = ds.shuffle(buffer_size=shuffle_buffer_size).repeat().batch(bs).prefetch(bs)
  return ds

def image_train_data(sess, bs):
    #bs=1097
    train_image = get_lung_cancer_image_training_data()
    data_dir = pathlib.Path(train_image[0])
    list_ds = tf.data.Dataset.list_files(str(data_dir/'*')) #train_image[0]+'\*.png' list(data_dir.glob('*/*.png'))
    labeled_ds = list_ds.map(process_path, num_parallel_calls=AUTOTUNE)
    train_ds = prepare_for_training(bs, labeled_ds)
    iter = tf.compat.v1.data.Iterator.from_structure(tf.compat.v1.data.get_output_types(train_ds),
                                           tf.compat.v1.data.get_output_shapes(train_ds))
    train_ds = iter.make_initializer(train_ds)
    image, label = iter.get_next()
    image = tf.reshape(image, [bs, 1, IMG_WIDTH, IMG_HEIGHT])
    return image, label
    #sess.run(train_ds.initializer)
    #while True:
    #   yield image, label

def load_train_input():
    IMG_WIDTH=150
    IMG_HEIGHT=150
    train_image = get_lung_cancer_image_training_data()
    input_dataset = (train_image[0])
    nFiles=len(os.listdir(input_dataset))
    if K.image_data_format() == 'channels_first': #
        dim=(  IMG_WIDTH, IMG_HEIGHT,1)
        img_data_array = np.empty((nFiles, IMG_WIDTH, IMG_HEIGHT,1))
    else:
        dim=(IMG_WIDTH, IMG_HEIGHT, 1)
        img_data_array = np.empty((nFiles, IMG_WIDTH, IMG_HEIGHT, 1))
            
    class_name = np.empty((nFiles, ))
    n=0
    for file in os.listdir(input_dataset):
        image_path= os.path.join(input_dataset, file)            
        image= cv.imread( image_path, cv.COLOR_BGR2RGB) #image= np.array(Image.open(image_path))
        image=cv.resize(image, (IMG_WIDTH, IMG_HEIGHT),interpolation = cv.INTER_AREA)
        image=np.array(image)
        image = image.astype('float32')
        image=image.reshape(dim)
        image /= 255 # normalize         
        lbl=file.split('_')[0]# one hot encode
        label = CLASS_NAMES.index(lbl)
        img_data_array[n, :, :, :] = image
        class_name[n] = label
        n=n+1
        
    class_name=array(class_name)
    #class_name = to_categorical(class_name, len(CLASS_NAMES))
    return img_data_array, class_name
    '''
    train_size=int(((80 * n)/100))
    test_size=int(((20 * n)/100))-1
    x_train, y_train=img_data_array[:train_size], class_name[:train_size]
    x_test, y_test=img_data_array[:test_size], class_name[:test_size]   
    '''            
        

def image_validation_data(sess, bs):
    val_files = get_lung_cancer_image_validation_data()
    data_dir = pathlib.Path(val_files[0])
    list_ds = tf.data.Dataset.list_files(str(data_dir/'*')) #train_image[0]+'\*.png' list(data_dir.glob('*/*.png'))
    labeled_ds = list_ds.map(process_path, num_parallel_calls=AUTOTUNE)
    val_ds = prepare_for_training(bs, labeled_ds)
    val_ds=val_ds.make_initializable_iterator()  
    image, label = val_ds.get_next()
    image = tf.reshape(image, [bs, 1, IMG_WIDTH, IMG_HEIGHT])
    sess.run(val_ds.initializer)
    while True:
        yield image, label  
    

def parse_data(x, y):
    x = x.decode()

    image = x
    label = y.astype(np.int32)

    return image, label

def tf_parse(x, y):
    #x, y = tf.numpy_function(parse_data, [x, y], [tf.float32, tf.int32])
    x.set_shape((1,150, 150 ))
    y.set_shape((5))
    return x, y

'Read all numpy files in dataset for training'
def numpy_train_data(bs,  aug=None):
    folder_path = './TrainingAugImages'
    shutil.rmtree(folder_path, ignore_errors = True)
    os.mkdir(folder_path)
    train_files = get_mias_numpy_training_data()
    train_image = np.load(train_files[0])
    # Normalize the images.
    #train_image = (train_image / 255) - 0.5
    train_labels = np.load(train_files[1])
    train_dataset = tf.data.Dataset.from_tensor_slices((train_image, train_labels))
    train_dataset = train_dataset.shuffle(buf_size).batch(bs)
    
    train_dataset = iter(train_dataset)
    image, label = train_dataset.get_next()
    label = tf.one_hot(train_labels, NUM_CLASSES)
    image = tf.reshape(image, [bs, 1, IMG_WIDTH, IMG_HEIGHT])
    image=image.numpy() #.eval(session=sess)  #
    label=label.numpy() #.eval(session=sess) #.numpy() #
    
    print(image.shape)
    print(label.shape)
    return image, label

def numpy_validation_data(bs,  aug=None):
    folder_path = './ValidationAugImages'
    shutil.rmtree(folder_path, ignore_errors = True)
    os.mkdir(folder_path)
    
    validation_files = get_mias_numpy_validation_data()
    validation_image = np.load(validation_files[0])
    validation_labels = np.load(validation_files[1])
    validation_dataset = tf.data.Dataset.from_tensor_slices((validation_image, validation_labels))
    validation_dataset = validation_dataset.batch(bs) #.make_initializable_iterator()  
    validation_dataset=tf.compat.v1.data.make_initializable_iterator(validation_dataset)  
    image, label = validation_dataset.get_next()
    label = tf.one_hot(label, NUM_CLASSES)
    image = tf.reshape(image, [bs, 1, IMG_WIDTH, IMG_HEIGHT])
    
def numpy_test_data(bs,  aug=None):
    folder_path = './TestAugImages'
    shutil.rmtree(folder_path, ignore_errors = True)
    os.mkdir(folder_path)
    
    test_files = get_mias_numpy_test_data()
    test_image = np.load(test_files[0])
    test_labels = np.load(test_files[1])
    test_dataset = tf.data.Dataset.from_tensor_slices((test_image, test_labels))
    test_dataset = test_dataset.batch(bs) #.make_initializable_iterator()  
    test_dataset=tf.compat.v1.data.make_initializable_iterator(test_dataset)  
    image, label = test_dataset.get_next()
    label = tf.one_hot(label, NUM_CLASSES)
    image = tf.reshape(image, [bs, 1, IMG_WIDTH, IMG_HEIGHT])
    

def get_training_data_old(what=10):
    if what == 10:
        train_files = [train_path_10, train_path_11, train_path_12, train_path_13]
        total_records = 55890
    else:
        raise ValueError('Invalid dataset!')

    return train_files, total_records

def get_test_data(what=10):
    test_files = [train_path_14]
    
    return [test_files], 11178
      
"""
Image loading functions
"""
def load_images_from_source2(data_dir, CLASS_NAMES):    
    list_ds = tf.data.Dataset.list_files(str(data_dir/'*/*'))
    dataset=0;
    for file_path in list_ds:   #.take(5)
        # convert the path to a list of path components
        parts = tf.strings.split(file_path, '/')
        img = tf.io.read_file(file_path)
        # convert the compressed string to a 3D uint8 tensor
        img = tf.image.decode_jpeg(img, channels=3)
        # Use `convert_image_dtype` to convert to floats in the [0,1] range.
        img = tf.image.convert_image_dtype(img, tf.float32)
        # resize the image to the desired size.
        img = tf.image.resize(img, [IMG_WIDTH, IMG_HEIGHT])

        # The second to last is the class-directory
        label = parts[-2] == CLASS_NAMES
        
        print("Image shape: ", img.numpy().shape)
        print("Label: ", label.numpy())
        print(file_path.numpy())
        dataset.append(img, label)
        
    return dataset

