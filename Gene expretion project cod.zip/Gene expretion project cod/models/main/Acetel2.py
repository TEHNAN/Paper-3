# -*- coding: utf-8 -*-
"""
Created on Fri Jun 18 12:50:19 2021

@author: Oyelade
"""

p={'a':3, 'b':4, 'c':5}
print(p['a':])