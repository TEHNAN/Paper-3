#!/usr/bin/env python
# ------------------------------------------------------------------------------------------------------%
# Created by "Thieu Nguyen" at 15:20, 25/03/2020                                                        %
#                                                                                                       %
#       Email:      nguyenthieu2102@gmail.com                                                           %
#       Homepage:   https://www.researchgate.net/profile/Thieu_Nguyen6                                  %
#       Github:     https://github.com/thieunguyen5991                                                  %
#-------------------------------------------------------------------------------------------------------%

from keras import backend
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import InputLayer
#from keras.models import Sequential
from pool_helper import PoolHelper
from tensorflow.python.keras.regularizers import l2
from tensorflow import keras
from lrn import LRN
#from tensorflow.python.keras.layers import Input, Dense, Conv2D, MaxPooling2D, AveragePooling2D, ZeroPadding2D, Dropout, Flatten, Concatenate, Reshape, Activation
from tensorflow.keras.layers  import LSTM, GRU, Input, Dense, Dropout, Conv2D, Flatten, MaxPooling2D, AveragePooling2D, ZeroPadding2D, Concatenate, Reshape, Activation
from keras.layers.convolutional import Conv1D, MaxPooling1D, ZeroPadding1D, AveragePooling1D
from models.root.traditional.root_rnn import RootRnn

from sklearn.metrics import classification_report, confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import cohen_kappa_score
from sklearn.metrics import roc_auc_score
import matplotlib.pyplot as plt
from tensorflow.keras.layers import BatchNormalization



class Rnn1HL(RootRnn):
	def __init__(self, root_base_paras=None, root_rnn_paras=None):
		RootRnn.__init__(self, root_base_paras, root_rnn_paras)
		self.filename = "RNN-1HL-" + root_rnn_paras["paras_name"]

	def _training__(self):
		#  The RNN 1-HL architecture
		self.model = Sequential()
		self.model.add(LSTM(units=self.hidden_sizes[0], activation=self.activations[0], input_shape=(self.X_train.shape[1], 1)))
		self.model.add(Dropout(self.dropouts[0]))
		self.model.add(Dense(units=1, activation=self.activations[1]))
		self.model.compile(loss=self.loss, optimizer=self.optimizer)
		ml = self.model.fit(self.X_train, self.y_train, epochs=self.epoch, batch_size=self.batch_size, verbose=self.log)
		self.loss_train = ml.history["loss"]


class Cnn1(RootRnn):
	def __init__(self, root_base_paras=None, root_rnn_paras=None, cnn_paras=None):
		RootRnn.__init__(self, root_base_paras, root_rnn_paras)
		self.filename = "CNN1-" + root_rnn_paras["paras_name"]
		self.filters_size = cnn_paras["filters_size"]
		self.kernel_size = cnn_paras["kernel_size"]
		self.pool_size = cnn_paras["pool_size"]

	def _training__(self):
		#  The CNN 1-HL architecture
		self.model = Sequential()
		self.model.add(Conv1D(filters=self.filters_size, kernel_size=self.kernel_size, activation=self.activations[0], input_shape=(self.X_train.shape[1], 1)))
		self.model.add(MaxPooling1D(pool_size=self.pool_size))
		self.model.add(Flatten())
		self.model.add(Dense(self.hidden_sizes[0], activation=self.activations[1]))
		self.model.add(Dense(1))
		self.model.compile(loss=self.loss, optimizer=self.optimizer)
		# fit mode
		ml = self.model.fit(self.X_train, self.y_train, epochs=self.epoch, batch_size=self.batch_size, verbose=self.log)
		self.loss_train = ml.history["loss"]
        
        
class Cnn6HL(RootRnn):
    """
        CNN with 6 Hidden Layer
    """
    def __init__(self, root_base_paras=None, root_rnn_paras=None, cnn_paras=None):
        RootRnn.__init__(self, root_base_paras, root_rnn_paras)
        self.filename = "CNN-6H-"#+ root_rnn_paras["paras_name"]
        self.filters_size = cnn_paras["filters_size"]
        self.kernel_size = cnn_paras["kernel_size"]
        self.pool_size = cnn_paras["pool_size"]

    def _training__(self):        
        self.model = Sequential()
        num_classes=2
        
        self.model.add(InputLayer(input_shape=(  150, 150,1), name='input'))
        self.model.add(Conv2D(32, (3,3), strides=(1,1), padding='same',
                              activation=self.activations[0], name='conv1_1/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(32, (3,3), strides=(1,1), padding='same', 
                              activation=self.activations[1], 
                              name='conv1_2/3x3_s1', kernel_regularizer=l2(0.0002)))
        
        self.model.add(ZeroPadding2D(padding=(1, 1))) 
         
        self.model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding='same', name='pool1/2x2_s1'))
         
        
        self.model.add(Conv2D(64, (3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv2_1/3x3_reduce', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(64, (3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv2_2/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2), padding='same', name='pool2/3x3_s2'))
        
        
        self.model.add(Conv2D(128, (3,3), strides=(1,1), padding='same', 
                              activation=self.activations[1],  
                              name='conv3_1/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(128, (3,3), strides=(1), padding='same', 
                              activation=self.activations[1],  
                              name='conv3_2/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding='same', name='pool3/2x2_s1'))
         
        self.model.add(Conv2D(256, (3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv4_1/3x3_reduce', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(256, (3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv4_2/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2), padding='same', name='pool4/3x3_s2'))
        
        '''
        self.model.add(Conv2D(512, (3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv5_1/3x3_s1', kernel_regularizer=l2(0.0002))) 
        self.model.add(Conv2D(512, (3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv5_2/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding='same', name='pool5/2x2_s1'))
         
       
        
        self.model.add(Conv2D(1024, (3,3), strides=(1,1), padding='same', 
                              activation=self.activations[1], 
                              name='conv6_1/3x3_reduce', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(1024, (3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv6_2/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2), padding='same', name='pool6/3x3_s2'))
        self.model.add(AveragePooling2D(pool_size=(2, 2), strides=(1, 1), name='pool7/2x2_s1'))
        '''
        self.model.add(Flatten())
        self.model.add(Dropout(rate=0.5))
        self.model.add(Dense(num_classes, name='loss3/classifier', kernel_regularizer=l2(0.0002)))
        self.model.add(Activation('softmax', name='prob'))
        
        self.model.summary()
        
        #self.loss  'categorical_crossentropy'
        self.model.compile(loss=self.loss, optimizer=self.optimizer, metrics=['accuracy'])
        '''
        backend.set_session(backend.tf.Session(
            config=backend.tf.ConfigProto(intra_op_parallelism_threads=2, inter_op_parallelism_threads=2)))
        '''
        #self.batch_size
        ml = self.model.fit(self.X_train, self.y_train, 
                                validation_data=(self.X_test, self.y_test),
                                validation_steps=self.X_test.shape[0]//32,
                                epochs=10, batch_size=32, verbose=self.log)
        self.loss_train = ml.history["loss"]
        self.accuracy_train = ml.history["accuracy"]
        y_pred = self.model.predict(self.X_test)
    
        yhat_classes_2 = y_pred.argmax(axis=1) 
        classes_2=self.y_test.argmax(axis=1)  #np.argmax(y_true, axis=1)
        print(y_pred)
        print(y_pred.shape)
        print(classes_2)
        print(str(len(classes_2))+'Confusion Matrix1'+str(yhat_classes_2.shape))
        print(confusion_matrix(classes_2, yhat_classes_2))
        cm = confusion_matrix(classes_2, yhat_classes_2)
        ##########################################################
        plt.imshow(cm, cmap=plt.cm.Blues)
        plt.xlabel("Predicted labels")
        plt.ylabel("True labels")
        plt.xticks([], [])
        plt.yticks([], [])
        plt.title('Confusion matrix ')
        plt.colorbar()
        plt.show()

        
        print('Classification Report')
        print(classification_report(classes_2, yhat_classes_2))
        # accuracy: (tp + tn) / (p + n)
        accuracy = accuracy_score(classes_2, yhat_classes_2)
        print('Accuracy: %f' % accuracy)
        
        # precision tp / (tp + fp)
        precision = precision_score(classes_2, yhat_classes_2, average='micro')
        print('Precision micro: %f' % precision)
        precision2 = precision_score(classes_2, yhat_classes_2, average='macro')
        print('Precision macro: %f' % precision2)
        precision3 = precision_score(classes_2, yhat_classes_2, average='weighted')
        print('Precision weighted: %f' % precision3)
        precision4 = precision_score(classes_2, yhat_classes_2, average=None)
        print('Precision None: ' + str(precision4))
        
        # recall: tp / (tp + fn)
        recall = recall_score(classes_2, yhat_classes_2, average='micro')
        print('Recall micro: %f' % recall)
        recall2 = recall_score(classes_2, yhat_classes_2, average='macro')
        print('Recall macro: %f' % recall2)
        recall3 = recall_score(classes_2, yhat_classes_2, average='weighted')
        print('Recall weighted: %f' % recall3)
        recall4 = recall_score(classes_2, yhat_classes_2, average=None)
        print('Recall None: ' + str(recall4))
        
        # f1: 2 tp / (2 tp + fp + fn)
        f1 = f1_score(classes_2, yhat_classes_2, average='micro')
        print('F1 score micro: %f' % f1)
        f1_2 = f1_score(classes_2, yhat_classes_2, average='macro')
        print('F1 score macro: %f' % f1_2)
        f1_3 = f1_score(classes_2, yhat_classes_2, average='weighted')
        print('F1 score weighted: %f' % f1_3)
        f1_4 = f1_score(classes_2, yhat_classes_2, average=None)
        print('F1 score None: ' + str(f1_4))
        
        # kappa
        kappa = cohen_kappa_score(classes_2, yhat_classes_2)
        print('Cohens kappa: %f' % kappa)
        
        CM = confusion_matrix(classes_2, yhat_classes_2)
        TN = CM[0][0]
        FN = CM[1][0]
        TP = CM[1][1]
        FP = CM[0][1]
        specificity = TN / (TN+FP)
        sensitivity  = TP / (TP+FN)
        print('specificity3: %f' % specificity)
        print('sensitivity3: %f' % sensitivity)
        self._save_train_results__(accuracy, [precision, precision2, precision3, precision4],[recall, recall2, recall3, recall4],
                                   [f1, f1_2, f1_3, f1_4], kappa, sensitivity, specificity)
       
         
        
class CnnLenetHL(RootRnn):
    """
        CNN with Lenet Hidden Layer
    """
    def __init__(self, root_base_paras=None, root_rnn_paras=None, cnn_paras=None):
        RootRnn.__init__(self, root_base_paras, root_rnn_paras)
        self.filename = "CNN-Lenet-"+ root_rnn_paras["paras_name"]
        self.filters_size = cnn_paras["filters_size"]
        self.kernel_size = cnn_paras["kernel_size"]
        self.pool_size = cnn_paras["pool_size"]

    def _training__(self):        
        self.model = Sequential()
        num_classes=2
        
        self.model.add(Conv2D(32, (3,3), strides=(1,1), padding='same',
                              #self.X_train.shape[1], self.X_train.shape[1]
                              activation=self.activations[0], input_shape=(144, 144,1 ), 
                              name='conv1_1/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(32, (3,3), strides=(1,1), padding='same', 
                              activation=self.activations[1], 
                              name='conv1_2/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(128, (5,5), strides=(1,1), padding='same', 
                              activation=self.activations[1], 
                              name='conv1_3/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1))) 
        self.model.add(MaxPooling2D(pool_size=(2,2), strides=(1, 1), padding='same', name='pool1/2x2_s1'))
        
        self.model.add(Conv2D(64, (3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv2_1/3x3_reduce', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(64, (3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv2_2/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(256, (5,5), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv2_3/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2), padding='same', name='pool2/3x3_s2'))
        
        self.model.add(Conv2D(128, (3,3), strides=(1,1), padding='same', 
                              activation=self.activations[1],  
                              name='conv3_1/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(128, (3,3), strides=(1), padding='same', 
                              activation=self.activations[1],  
                              name='conv3_2/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(256, (5,5), strides=(1), padding='same', 
                              activation=self.activations[1],  
                              name='conv3_3/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding='same', name='pool3/2x2_s1'))
        
        self.model.add(Conv2D(256, (3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv4_1/3x3_reduce', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(256, (3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv4_2/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(1024, (5,5), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv4_3/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2), padding='same', name='pool4/3x3_s2'))
        
        self.model.add(Conv2D(512, (3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv5_1/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(512, (3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv5_2/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(2048, (5,5), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv5_3/3x3_s1', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(2, 2), strides=(1, 1), padding='same', name='pool5/2x2_s1'))
        
        self.model.add(Conv2D(1024, (3,3), strides=(1,1), padding='same', 
                              activation=self.activations[1], 
                              name='conv6_1/3x3_reduce', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(1024, (3,3), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv6_2/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(Conv2D(1024, (5,5), strides=(1, 1), padding='same', 
                              activation=self.activations[1], 
                              name='conv6_3/3x3', kernel_regularizer=l2(0.0002)))
        self.model.add(ZeroPadding2D(padding=(1, 1)))
        self.model.add(MaxPooling2D(pool_size=(3, 3), strides=(2, 2), padding='same', name='pool6/3x3_s2'))
        self.model.add(AveragePooling2D(pool_size=(2, 2), strides=(1, 1), name='pool7/2x2_s1'))
        
        self.model.add(Flatten())
        self.model.add(Dropout(rate=0.5))
        self.model.add(Dense(num_classes, name='loss3/classifier', kernel_regularizer=l2(0.0002)))
        self.model.add(Activation('softmax', name='prob'))
        
        self.model.summary()
        
        #self.loss  'categorical_crossentropy'
        self.model.compile(loss=self.loss, optimizer=self.optimizer, metrics=['accuracy'])
        ml = self.model.fit(self.X_train, self.y_train, epochs=self.epoch, batch_size=self.batch_size, verbose=self.log)
        self.loss_train = ml.history["loss"]
        self.accuracy_train = ml.history["accuracy"]
        
        '''
        # scatter plot of blobs dataset
        from sklearn.datasets import make_blobs
        from numpy import where
        from matplotlib import pyplot
        # generate dataset
        X, y = make_blobs(n_samples=1000, centers=3, n_features=2, cluster_std=2, random_state=2)
        # select indices of points with each class label
        for i in range(3):
        	samples_ix = where(y == i)
        	pyplot.scatter(X[samples_ix, 0], X[samples_ix, 1])
        pyplot.show()
        '''