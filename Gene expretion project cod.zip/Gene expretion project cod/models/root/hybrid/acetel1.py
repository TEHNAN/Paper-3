# -*- coding: utf-8 -*-
"""
Created on Thu Jun 17 15:30:28 2021

@author: Oyelade
"""

for count in range(100001):
    if count%2 == 0:
        print('Even number ', count)
    else:
        print('Odd number ', count)