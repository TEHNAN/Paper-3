# -*- coding: utf-8 -*-
"""
Created on Wed Feb 17 13:18:53 2021

@author: Oyelade
"""

import matplotlib.pyplot as plt
plt.style.use('seaborn-whitegrid')
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter

hybrids1=['C1-CNN', 'CNN-GA', 'CNN-WOA', 'CNN-MVO', 'CNN-SBO', 'CNN-LCBO']
hybrids2=['C2-CNN', 'CNN-GA', 'CNN-WOA', 'CNN-MVO', 'CNN-SBO', 'CNN-LCBO']
times=['TTT', 'TET', 'TPT',  'TST']
metrics=['Accuracy', 'Precision', 'Recall', 'F1 score'] #, 'Specificity' 'Specificity', 'Sensitivity', 'Jaccard score']

        # TTT,TET,TPT,TST
data = [[78.8228,	7.8823,	1.43759346,	84.8427],   #CNN 78.8228	7.8823	1.43759346	84.8427
        [7170.788,	1434.158,	3.512005,	7182.433], # GA 7170.788	1434.158	3.512005	7182.433
        [3313.194,	662.6389,	3.352049,	3324.261], # WAO 3313.194	662.6389	3.352049	3324.261
        [5812.955,	1162.591,	3.365529,	5823.051],   # MVO 5812.955	1162.591	3.365529	5823.051
        [3702.616,	740.5231,	3.40275,	3714.189],  # SBO 3702.616	740.5231	3.40275	3714.189
        [5703.106,	1140.621,	3.294338,	5714.593]  # LCBO 5703.106	1140.621	3.294338	5714.593
       ]
X = np.arange(4)
fig = plt.figure(figsize=(4,4))
ax = fig.add_axes([0,0,1,1])

ax.bar(X + 0.00, data[0], color = 'b', width = 0.10)
ax.bar(X + 0.10, data[1], color = 'g', width = 0.10)
ax.bar(X + 0.20, data[2], color = 'r', width = 0.10)
ax.bar(X + 0.30, data[3], color = 'y', width = 0.10)
ax.bar(X + 0.40, data[4], color = 'c', width = 0.10)
ax.bar(X + 0.50, data[5], color = 'm', width = 0.10)
ax.legend(labels=hybrids1)
plt.xticks([r + 0.10 for r in range(4)], times) 
plt.show()
         # Acc    Pre    Rec,  F1,   Spec, Sens 
data2 = [
        [0.86, 0.73,  0.86,    0.79], #CNN 0.86, 0.73,  0.86, 0.79, 1.0
        [0.96,	0.92,  0.96,    0.94], # GA 0.0156	0.01	1.00	0.03	0
        [0.89,	0.92, 	0.89, 	0.90],# WAO 0.260	0.91 	0.26 	0.39 	0.9895
        [0.96,	0.92,	0.96,	0.98],  # MVO 0.0156	0.0156	0.0156	0.0156	0
        [0.96,	0.92, 	0.96,	0.94],# SBO, 0.91	0.92 	0.92 	0.92 	0.952
        [0.96,	0.96, 	0.96, 	0.98]  # LCBO   0.960	0.92 	0.96 	0.94	1	
       ]
X = np.arange(4)
fig = plt.figure()
axi = fig.add_axes([0,0,1,1])

axi.bar(X + 0.00, data2[0], color = 'b', width = 0.10)
axi.bar(X + 0.10, data2[1], color = 'g', width = 0.10)
axi.bar(X + 0.20, data2[2], color = 'r', width = 0.10)
axi.bar(X + 0.30, data2[3], color = 'y', width = 0.10)
axi.bar(X + 0.40, data2[4], color = 'c', width = 0.10)
#axi.bar(X + 0.50, data2[5], color = 'm', width = 0.10)
axi.legend(hybrids1,bbox_to_anchor=(1.00, 1.05))
plt.xticks([r + 0.10 for r in range(4)], metrics) 
plt.show()